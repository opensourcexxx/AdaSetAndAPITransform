+            byte[] bytes = Utils.newBytes(len);
