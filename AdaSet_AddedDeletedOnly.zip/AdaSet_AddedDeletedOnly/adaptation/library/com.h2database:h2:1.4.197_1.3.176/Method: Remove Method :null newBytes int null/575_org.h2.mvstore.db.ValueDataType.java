+                byte[] b = Utils.newBytes(len);
