+                byte[] d2 = Utils.newBytes(paramLen);
