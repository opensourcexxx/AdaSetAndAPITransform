+            byte[] buff = Utils.newBytes(len);
