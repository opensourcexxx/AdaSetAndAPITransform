+                data = Utils.newBytes(len);
