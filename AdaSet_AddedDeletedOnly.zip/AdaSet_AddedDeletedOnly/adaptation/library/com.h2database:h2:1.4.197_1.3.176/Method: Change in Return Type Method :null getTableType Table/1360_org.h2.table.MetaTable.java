+                if (table.getTableType() != TableType.VIEW) {
