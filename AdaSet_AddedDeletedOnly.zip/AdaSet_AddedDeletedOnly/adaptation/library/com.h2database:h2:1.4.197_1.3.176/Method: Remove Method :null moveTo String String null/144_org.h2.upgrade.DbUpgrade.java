+            FileUtils.move(data, backupData);
+            FileUtils.move(index, backupIndex);
