+        this.arguments = ArgumentsProcessor.expandArgs(mockitoMethod, args);
