+        this.arguments = ArgumentsProcessor.expandArgs(mockitoMethod, arguments);
