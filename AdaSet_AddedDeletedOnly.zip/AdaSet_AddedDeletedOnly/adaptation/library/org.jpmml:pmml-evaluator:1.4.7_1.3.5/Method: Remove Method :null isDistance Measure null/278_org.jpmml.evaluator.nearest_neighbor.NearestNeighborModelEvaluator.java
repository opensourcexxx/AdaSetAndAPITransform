+		if(measure instanceof Distance){
+			return evaluateDistance(valueFactory, comparisonMeasure, knnInputs.getKNNInputs(), values);
