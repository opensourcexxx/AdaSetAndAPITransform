+		if(measure instanceof Distance){
+			result = evaluateDistance(valueFactory, comparisonMeasure, clusteringFields, values);
