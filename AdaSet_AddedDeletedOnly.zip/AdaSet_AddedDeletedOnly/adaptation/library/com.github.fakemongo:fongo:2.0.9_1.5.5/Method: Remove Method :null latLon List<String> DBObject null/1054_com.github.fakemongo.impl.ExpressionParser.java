+        Geometry local = GeoUtil.toGeometry(Util.extractField(o, path));
+        return GeoUtil.geowithin(local, geometry);
