+        double distance = GeoUtil.distanceInRadians(geometry, objectGeometry, sphere);
+        o.put(FongoDBCollection.FONGO_SPECIAL_ORDER_BY, distance);
+        return maxDistance == null || distance < maxDistance.doubleValue();
