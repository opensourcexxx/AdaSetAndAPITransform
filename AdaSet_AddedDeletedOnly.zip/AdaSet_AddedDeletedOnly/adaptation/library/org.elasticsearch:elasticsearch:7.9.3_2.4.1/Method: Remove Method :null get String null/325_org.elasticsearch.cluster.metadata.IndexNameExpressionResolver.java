+            IndexAbstraction indexAbstraction = state.metadata().getIndicesLookup().get(expression);
+            if (indexAbstraction != null && indexAbstraction.getType() == IndexAbstraction.Type.ALIAS) {
+                IndexAbstraction.Alias alias = (IndexAbstraction.Alias) indexAbstraction;
+                for (Tuple<String, AliasMetadata> item : alias.getConcreteIndexAndAliasMetadatas()) {
