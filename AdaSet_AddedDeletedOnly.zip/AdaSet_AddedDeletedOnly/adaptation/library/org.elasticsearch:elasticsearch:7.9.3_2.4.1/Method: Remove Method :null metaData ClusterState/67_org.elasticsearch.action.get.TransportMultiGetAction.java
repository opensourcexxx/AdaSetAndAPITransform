+
+            String concreteSingleIndex;
+            try {
+                concreteSingleIndex = indexNameExpressionResolver.concreteSingleIndex(clusterState, item).getName();
+
+                item.routing(clusterState.metadata().resolveIndexRouting(item.routing(), item.index()));
+                if ((item.routing() == null) && (clusterState.getMetadata().routingRequired(concreteSingleIndex))) {
+                    responses.set(i, newItemFailure(concreteSingleIndex, item.type(), item.id(),
+                        new RoutingMissingException(concreteSingleIndex, item.type(), item.id())));
+                    continue;
+                }
+            } catch (Exception e) {
+                responses.set(i, newItemFailure(item.index(), item.type(), item.id(), e));
