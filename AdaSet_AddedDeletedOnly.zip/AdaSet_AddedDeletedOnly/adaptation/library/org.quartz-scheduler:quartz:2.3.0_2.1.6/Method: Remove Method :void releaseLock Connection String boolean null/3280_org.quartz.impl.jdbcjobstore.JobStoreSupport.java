+                releaseLock(LOCK_TRIGGER_ACCESS, transOwner);
