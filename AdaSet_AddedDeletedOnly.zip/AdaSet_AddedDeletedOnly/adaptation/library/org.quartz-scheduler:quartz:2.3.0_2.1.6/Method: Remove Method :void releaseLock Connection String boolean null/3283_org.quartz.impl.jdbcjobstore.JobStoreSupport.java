+                    releaseLock(LOCK_STATE_ACCESS, transStateOwner);
