+        return new ResultSetProxyImpl(statement, resultSet, dataSource.createResultSetId(),
+                statement.getLastExecuteSql());
