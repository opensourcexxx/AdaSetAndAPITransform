+                decodeRemovalReentryProtection(ctx, in, out);
