+        if (in.isReadable()) {
+            // Only call decode() if there is something left in the buffer to decode.
+            // See https://github.com/netty/netty/issues/4386
+            decodeRemovalReentryProtection(ctx, in, out);
+        }
