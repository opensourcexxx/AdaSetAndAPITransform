+    HBaseRpcController controller =
+        ((ClusterConnection) connection).getRpcControllerFactory().newController();
