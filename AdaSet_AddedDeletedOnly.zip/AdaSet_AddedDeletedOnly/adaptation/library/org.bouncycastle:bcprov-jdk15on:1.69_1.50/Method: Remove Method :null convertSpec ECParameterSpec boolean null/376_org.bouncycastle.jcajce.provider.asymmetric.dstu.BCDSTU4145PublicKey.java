+            return EC5Util.convertSpec(ecSpec);
