+                curveSpec = EC5Util.convertSpec((java.security.spec.ECParameterSpec)parameter);
