+        ASN1ObjectIdentifier oid = getOID(name);
+        return oid == null ? null : getByOID(oid);
