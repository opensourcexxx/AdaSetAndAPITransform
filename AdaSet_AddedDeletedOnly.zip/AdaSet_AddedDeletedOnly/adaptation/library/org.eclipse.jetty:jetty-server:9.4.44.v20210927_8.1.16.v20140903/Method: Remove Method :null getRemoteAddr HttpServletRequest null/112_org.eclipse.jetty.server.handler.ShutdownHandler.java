+            LOG.warn("Unauthorized non-loopback shutdown attempt from " + request.getRemoteAddr());
