+            LOG.warn("Unauthorized tokenless shutdown attempt from " + request.getRemoteAddr());
