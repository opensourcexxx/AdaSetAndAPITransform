+        return pos >= length ? EOF : input[pos];
