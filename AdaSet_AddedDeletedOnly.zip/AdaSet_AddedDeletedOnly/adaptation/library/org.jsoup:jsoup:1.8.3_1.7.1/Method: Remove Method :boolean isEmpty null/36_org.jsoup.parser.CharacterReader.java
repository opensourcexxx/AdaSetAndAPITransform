+        char val = pos >= length ? EOF : input[pos];
