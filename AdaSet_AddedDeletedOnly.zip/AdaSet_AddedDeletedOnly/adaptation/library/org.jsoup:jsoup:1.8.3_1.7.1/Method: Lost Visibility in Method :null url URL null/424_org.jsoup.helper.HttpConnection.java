+
+                    String location = res.header(LOCATION);
+                    if (location != null && location.startsWith("http:/") && location.charAt(6) != '/') // fix broken Location: http:/temp/AAG_New/en/index.php
+                        location = location.substring(6);
+                    req.url(StringUtil.resolve(req.url(), encodeUrl(location)));
+
