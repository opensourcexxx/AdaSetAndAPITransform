+            final byte[] buffer = ensureBufferSize(decodeSize, context);
+            final byte b = in[inPos++];
