+                final byte[] buffer = ensureBufferSize(decodeSize, context);
