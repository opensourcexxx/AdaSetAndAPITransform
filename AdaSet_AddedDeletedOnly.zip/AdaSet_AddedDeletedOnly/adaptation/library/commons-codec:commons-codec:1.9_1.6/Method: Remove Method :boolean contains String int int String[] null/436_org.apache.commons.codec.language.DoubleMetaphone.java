+        } else if (index == 0 &&
+                   (charAt(value, index + 1) == 'Y' ||
+                    contains(value, index + 1, 2, ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER))) {
