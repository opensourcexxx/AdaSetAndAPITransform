+                } else if (!contains(value, index + 1, 1, L_T_K_S_N_M_B_Z) &&
+                           !contains(value, index - 1, 1, "S", "K", "L")) {
