+        if (!isLockOwner(lockName)) {
