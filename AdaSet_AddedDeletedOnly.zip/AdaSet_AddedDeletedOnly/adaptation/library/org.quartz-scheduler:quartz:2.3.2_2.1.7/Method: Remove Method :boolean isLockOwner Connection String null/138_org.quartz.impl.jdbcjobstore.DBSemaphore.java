+        if (isLockOwner(lockName)) {
