+            code.append(CodedConstant.getMappedWriteCode(field, "output", 
+                    field.getOrder(), field.getFieldType(), isList));
