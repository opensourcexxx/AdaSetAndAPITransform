+            code.append(CodedConstant.getMappedTypeSize(field, field.getOrder(), 
+                    field.getFieldType(), isList, debug, outputPath));
