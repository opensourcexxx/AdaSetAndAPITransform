+        if (_inputPtr < _inputEnd || _loadMore()) {
