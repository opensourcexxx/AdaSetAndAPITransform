+            if (!_loadMore()) {
+                _reportInvalidEOF(eofMsg, forToken);
+            }
