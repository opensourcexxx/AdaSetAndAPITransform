+            if (!_loadMore()) {
+                _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
