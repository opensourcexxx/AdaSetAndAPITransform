+            _writeValueAndClose(createGenerator(bb, JsonEncoding.UTF8), value);
