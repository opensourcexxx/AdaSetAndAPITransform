+        _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
