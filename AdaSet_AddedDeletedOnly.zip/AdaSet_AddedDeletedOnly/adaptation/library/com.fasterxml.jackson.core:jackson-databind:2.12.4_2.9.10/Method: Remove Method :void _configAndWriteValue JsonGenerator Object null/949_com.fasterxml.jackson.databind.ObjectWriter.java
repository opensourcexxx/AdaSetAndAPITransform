+        _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
