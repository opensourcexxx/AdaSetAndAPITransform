+            _writeValueAndClose(createGenerator(sw), value);
