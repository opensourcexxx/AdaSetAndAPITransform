+        _appendEndMarker(JsonToken.END_ARRAY);
