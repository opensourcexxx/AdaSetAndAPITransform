+    return new BasicCertificateChainCleaner(buildTrustRootIndex(trustManager));
