+			.setMathContext(ModelUtil.simplifyMathContext(mathContext))
+			.setOutput(hasProbabilityDistribution ? ModelUtil.createProbabilityOutput(mathContext, categoricalLabel) : null);
