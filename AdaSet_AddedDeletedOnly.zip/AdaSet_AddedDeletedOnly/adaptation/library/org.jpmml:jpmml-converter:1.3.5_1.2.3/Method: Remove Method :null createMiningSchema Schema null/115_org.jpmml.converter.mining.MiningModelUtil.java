+		MiningModel miningModel = new MiningModel(lastModel.getMiningFunction(), miningSchema)
+			.setMathContext(ModelUtil.simplifyMathContext(lastModel.getMathContext()))
