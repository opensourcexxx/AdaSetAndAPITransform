+        _metadata = src._metadata;
