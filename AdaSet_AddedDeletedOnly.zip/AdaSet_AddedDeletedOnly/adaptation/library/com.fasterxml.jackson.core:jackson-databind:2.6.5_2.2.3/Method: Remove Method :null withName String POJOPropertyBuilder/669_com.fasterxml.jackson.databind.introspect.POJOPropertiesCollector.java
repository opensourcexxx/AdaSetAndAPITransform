+                prop = prop.withSimpleName(newName);
