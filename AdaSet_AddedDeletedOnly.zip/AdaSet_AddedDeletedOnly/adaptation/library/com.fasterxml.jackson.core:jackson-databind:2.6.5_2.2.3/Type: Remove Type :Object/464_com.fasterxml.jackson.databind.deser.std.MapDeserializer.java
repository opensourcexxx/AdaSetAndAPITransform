+                if (buffer.assignParameter(prop, prop.deserialize(p, ctxt))) {
+                    p.nextToken();
