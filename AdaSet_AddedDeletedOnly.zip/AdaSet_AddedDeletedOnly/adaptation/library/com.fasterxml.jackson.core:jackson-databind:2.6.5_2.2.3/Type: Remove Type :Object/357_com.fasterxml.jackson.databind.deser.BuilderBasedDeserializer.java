+                if (buffer.assignParameter(creatorProp, creatorProp.deserialize(jp, ctxt))) {
