+                if (buffer.assignParameter(creatorProp, creatorProp.deserialize(p, ctxt))) {
