+                    if (buffer.assignParameter(creatorProp, _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
+                        t = p.nextToken(); // to move to following FIELD_NAME/END_OBJECT
