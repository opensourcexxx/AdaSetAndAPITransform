+        Object pojo = roid.resolve();
