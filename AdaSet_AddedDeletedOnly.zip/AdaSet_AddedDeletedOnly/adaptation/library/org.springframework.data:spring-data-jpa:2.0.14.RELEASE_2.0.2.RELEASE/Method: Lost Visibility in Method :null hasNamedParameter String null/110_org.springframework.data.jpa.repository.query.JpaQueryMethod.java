+		if (!DeclaredQuery.of(annotatedQuery).hasNamedParameter()) {
