+            AsyncConnection connection = selectSet.getManager().newConnection(channel,ep, key.attachment());
+            ep.setConnection(connection);
+
+            AbstractHttpConnection httpConnection=(AbstractHttpConnection)connection;
+            httpConnection.setDestination(dest);
+
+            if (dest.isSecure() && !dest.isProxied())
+                ((UpgradableEndPoint)ep).upgrade();
+
+            dest.onNewConnection(httpConnection);
+
+            return scep;
