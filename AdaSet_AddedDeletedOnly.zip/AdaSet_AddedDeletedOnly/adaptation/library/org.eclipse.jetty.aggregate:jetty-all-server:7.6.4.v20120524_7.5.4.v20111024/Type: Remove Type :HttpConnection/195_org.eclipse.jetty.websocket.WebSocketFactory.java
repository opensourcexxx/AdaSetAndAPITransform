+        }
+        AbstractHttpConnection http = AbstractHttpConnection.getCurrentConnection();
+        if (http instanceof BlockingHttpConnection)
+            throw new IllegalStateException("Websockets not supported on blocking connectors");
