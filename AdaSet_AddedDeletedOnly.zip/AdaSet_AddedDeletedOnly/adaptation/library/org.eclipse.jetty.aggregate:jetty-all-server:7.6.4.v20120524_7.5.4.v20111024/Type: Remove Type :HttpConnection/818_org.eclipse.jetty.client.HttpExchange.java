+        AbstractHttpConnection result = _connection;
