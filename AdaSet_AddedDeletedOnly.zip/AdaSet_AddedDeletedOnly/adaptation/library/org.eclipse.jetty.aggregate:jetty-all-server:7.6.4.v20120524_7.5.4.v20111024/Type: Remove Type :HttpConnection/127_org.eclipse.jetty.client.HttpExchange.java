+        AbstractHttpConnection connection = _connection;
