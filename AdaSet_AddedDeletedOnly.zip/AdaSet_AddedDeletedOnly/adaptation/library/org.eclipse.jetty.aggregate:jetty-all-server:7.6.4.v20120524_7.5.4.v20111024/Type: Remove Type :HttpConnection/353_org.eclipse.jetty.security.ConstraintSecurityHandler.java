+        AbstractHttpConnection connection = AbstractHttpConnection.getCurrentConnection();
