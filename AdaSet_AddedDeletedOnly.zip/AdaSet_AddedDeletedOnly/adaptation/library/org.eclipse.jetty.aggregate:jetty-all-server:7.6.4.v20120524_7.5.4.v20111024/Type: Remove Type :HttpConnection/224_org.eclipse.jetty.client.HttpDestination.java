+        AbstractHttpConnection connection = getConnection(timeout);
