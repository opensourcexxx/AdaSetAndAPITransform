+                zf = new org.apache.commons.compress.archivers.zip.ZipFile( file, "utf-8" );
+                Enumeration<ZipArchiveEntry> entries = zf.getEntries();
+                HashSet<String> dirSet = new HashSet<String>();
+                while ( entries.hasMoreElements() )
