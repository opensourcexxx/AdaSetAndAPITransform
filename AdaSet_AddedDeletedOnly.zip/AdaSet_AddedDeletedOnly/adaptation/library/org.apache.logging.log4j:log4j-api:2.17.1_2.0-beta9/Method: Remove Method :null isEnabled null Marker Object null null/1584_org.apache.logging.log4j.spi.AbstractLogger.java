+        logIfEnabled(FQCN, Level.TRACE, marker, message, null);
