+        logIfEnabled(FQCN, Level.DEBUG, marker, message, null);
