+        logIfEnabled(FQCN, Level.ERROR, marker, message, null);
