+        logIfEnabled(FQCN, Level.FATAL, marker, message, null);
