+                return _finishAndReturnString(); // only strings can be incomplete
