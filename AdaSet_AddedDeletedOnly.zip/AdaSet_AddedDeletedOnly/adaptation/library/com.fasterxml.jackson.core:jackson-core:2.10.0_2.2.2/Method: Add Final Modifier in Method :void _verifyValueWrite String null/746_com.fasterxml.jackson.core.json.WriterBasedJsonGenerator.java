+        _verifyValueWrite(WRITE_BOOLEAN);
