+        _verifyValueWrite(WRITE_NUMBER);
