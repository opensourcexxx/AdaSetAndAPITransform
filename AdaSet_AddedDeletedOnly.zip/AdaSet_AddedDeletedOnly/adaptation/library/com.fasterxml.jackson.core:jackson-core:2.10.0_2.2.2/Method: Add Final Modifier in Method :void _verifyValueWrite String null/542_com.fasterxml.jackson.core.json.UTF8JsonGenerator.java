+        _verifyValueWrite(WRITE_STRING);
