+        _verifyValueWrite(WRITE_BINARY);
