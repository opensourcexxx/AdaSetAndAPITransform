+        if (includeDefaults || precisionStep != Defaults.PRECISION_STEP_32_BIT) {
