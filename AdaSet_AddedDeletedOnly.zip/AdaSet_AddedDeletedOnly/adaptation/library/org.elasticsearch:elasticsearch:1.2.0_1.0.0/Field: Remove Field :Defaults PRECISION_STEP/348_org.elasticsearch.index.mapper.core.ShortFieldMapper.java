+        if (includeDefaults || precisionStep != DEFAULT_PRECISION_STEP) {
