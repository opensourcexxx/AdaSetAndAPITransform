+        if (includeDefaults || precisionStep != Defaults.PRECISION_STEP_8_BIT) {
