+                    GeoUtils.parseGeoPoint(parser, point);
