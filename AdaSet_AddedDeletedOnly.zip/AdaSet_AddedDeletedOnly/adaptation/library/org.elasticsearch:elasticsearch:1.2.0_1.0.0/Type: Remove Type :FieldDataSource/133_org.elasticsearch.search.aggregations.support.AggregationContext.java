+        ValuesSource.Numeric source = new ValuesSource.Numeric.Script(config.script, config.scriptValueType);
