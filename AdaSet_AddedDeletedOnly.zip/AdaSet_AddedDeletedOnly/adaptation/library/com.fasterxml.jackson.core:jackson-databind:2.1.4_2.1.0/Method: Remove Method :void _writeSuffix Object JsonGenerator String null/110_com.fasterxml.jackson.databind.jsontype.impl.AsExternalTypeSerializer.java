+       _writeArraySuffix(value, jgen, idFromValue(value));
