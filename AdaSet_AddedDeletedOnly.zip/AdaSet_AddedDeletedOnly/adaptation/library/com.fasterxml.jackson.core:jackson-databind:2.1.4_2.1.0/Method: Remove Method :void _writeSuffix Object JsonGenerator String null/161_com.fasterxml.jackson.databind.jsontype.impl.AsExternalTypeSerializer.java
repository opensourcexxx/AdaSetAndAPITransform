+       _writeArraySuffix(value, jgen, typeId);
