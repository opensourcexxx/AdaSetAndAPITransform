+                IndexMetadata electedIndexMetadata = null;
+                int indexMetadataCount = 0;
