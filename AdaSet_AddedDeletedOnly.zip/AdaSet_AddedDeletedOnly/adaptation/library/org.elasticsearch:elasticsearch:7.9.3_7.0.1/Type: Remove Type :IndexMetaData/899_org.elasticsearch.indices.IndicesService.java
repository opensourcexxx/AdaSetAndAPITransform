+            final IndexMetadata metadata;
