+            final IndexMetadata indexMetadata = state.metadata().getIndexSafe(concreteIndex);
+            final int indexNumberOfShards = indexMetadata.getNumberOfShards();
