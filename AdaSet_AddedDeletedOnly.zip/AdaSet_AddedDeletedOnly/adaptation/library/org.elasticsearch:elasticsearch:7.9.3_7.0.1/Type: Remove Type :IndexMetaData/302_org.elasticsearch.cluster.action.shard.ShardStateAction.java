+                IndexMetadata indexMetadata = currentState.metadata().index(task.shardId.getIndex());
+                if (indexMetadata == null) {
