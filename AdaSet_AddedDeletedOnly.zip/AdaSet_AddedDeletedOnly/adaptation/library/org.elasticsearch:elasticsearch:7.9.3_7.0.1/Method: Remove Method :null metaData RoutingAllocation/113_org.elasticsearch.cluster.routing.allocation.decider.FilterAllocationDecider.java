+            IndexMetadata indexMd = allocation.metadata().getIndexSafe(shardRouting.index());
