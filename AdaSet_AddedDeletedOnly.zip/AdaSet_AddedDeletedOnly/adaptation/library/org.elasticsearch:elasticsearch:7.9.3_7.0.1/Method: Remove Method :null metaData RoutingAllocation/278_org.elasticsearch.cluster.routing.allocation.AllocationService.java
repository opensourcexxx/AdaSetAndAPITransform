+        final Metadata metadata = allocation.metadata();
