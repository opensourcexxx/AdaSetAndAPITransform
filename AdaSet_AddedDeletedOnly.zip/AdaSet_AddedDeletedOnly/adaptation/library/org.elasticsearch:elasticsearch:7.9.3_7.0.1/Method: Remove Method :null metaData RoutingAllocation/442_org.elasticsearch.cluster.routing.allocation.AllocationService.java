+            assert routingAllocation.metadata().index(startedShard.shardId().getIndex()) != null :
