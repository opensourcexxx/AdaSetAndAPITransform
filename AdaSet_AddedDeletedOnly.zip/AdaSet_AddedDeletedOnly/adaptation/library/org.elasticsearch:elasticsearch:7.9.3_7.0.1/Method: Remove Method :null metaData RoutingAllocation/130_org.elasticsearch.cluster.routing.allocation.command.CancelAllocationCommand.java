+            indexMetadata = allocation.metadata().index(index());
+            if (indexMetadata == null) {
