+                partitionKnownAndValidSettings(currentState.metadata().transientSettings(), "transient", logger);
