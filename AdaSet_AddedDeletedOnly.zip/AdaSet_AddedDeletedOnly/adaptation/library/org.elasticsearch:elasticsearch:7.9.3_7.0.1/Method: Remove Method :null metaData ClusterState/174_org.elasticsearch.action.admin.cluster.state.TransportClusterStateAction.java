+                mdBuilder = Metadata.builder(currentState.metadata());
