+            if (!clusterState.metadata().hasConcreteIndex(termVectorsRequest.index())) {
