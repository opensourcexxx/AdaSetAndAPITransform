+        if (clusterState.metadata().index(index) != null) {
