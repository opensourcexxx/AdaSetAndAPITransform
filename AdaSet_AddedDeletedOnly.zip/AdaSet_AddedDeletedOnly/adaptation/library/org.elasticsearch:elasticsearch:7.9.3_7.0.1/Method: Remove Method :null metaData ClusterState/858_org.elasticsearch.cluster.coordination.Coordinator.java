+            Metadata.Builder metadataBuilder = Metadata.builder(currentState.metadata());
