+        resolveAndValidateRouting(state.metadata(), request.concreteIndex(), request);
