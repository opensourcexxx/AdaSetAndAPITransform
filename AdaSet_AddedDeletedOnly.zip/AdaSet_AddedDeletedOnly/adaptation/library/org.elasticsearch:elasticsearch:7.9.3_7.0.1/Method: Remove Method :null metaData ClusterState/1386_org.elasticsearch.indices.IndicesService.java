+        IndexMetadata indexMetadata = state.metadata().index(index);
