+        ScriptMetadata scriptMetadata = state.metadata().custom(ScriptMetadata.TYPE);
