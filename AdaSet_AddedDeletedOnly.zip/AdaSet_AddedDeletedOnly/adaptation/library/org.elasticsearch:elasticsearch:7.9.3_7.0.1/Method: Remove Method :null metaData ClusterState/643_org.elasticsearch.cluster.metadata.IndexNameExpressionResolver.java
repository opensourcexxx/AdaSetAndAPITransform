+            Metadata metadata = context.getState().metadata();
+            // only check open/closed since if we do not expand to open or closed it doesn't make sense to
+            // expand to hidden
