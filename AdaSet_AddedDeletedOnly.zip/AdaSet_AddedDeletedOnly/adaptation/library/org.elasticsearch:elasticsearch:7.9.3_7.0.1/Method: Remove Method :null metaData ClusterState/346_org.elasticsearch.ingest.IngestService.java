+        IngestMetadata currentIngestMetadata = currentState.metadata().custom(IngestMetadata.TYPE);
