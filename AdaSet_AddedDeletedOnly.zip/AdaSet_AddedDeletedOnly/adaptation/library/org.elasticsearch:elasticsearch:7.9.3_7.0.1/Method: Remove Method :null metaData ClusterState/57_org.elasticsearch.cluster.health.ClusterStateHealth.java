+        this(clusterState, clusterState.metadata().getConcreteAllIndices());
