+            if (!state.metadata().hasConcreteIndex(concreteIndex)) {
