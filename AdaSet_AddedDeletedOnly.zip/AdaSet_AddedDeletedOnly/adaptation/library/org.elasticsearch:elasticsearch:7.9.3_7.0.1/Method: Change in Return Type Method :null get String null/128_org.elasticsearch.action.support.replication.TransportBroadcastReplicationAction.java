+            IndexMetadata indexMetadata = clusterState.metadata().getIndices().get(index);
+            if (indexMetadata != null) {
