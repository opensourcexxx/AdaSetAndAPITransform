+            AliasMetadata currentAliasMd = index.getAliases().get(alias);
