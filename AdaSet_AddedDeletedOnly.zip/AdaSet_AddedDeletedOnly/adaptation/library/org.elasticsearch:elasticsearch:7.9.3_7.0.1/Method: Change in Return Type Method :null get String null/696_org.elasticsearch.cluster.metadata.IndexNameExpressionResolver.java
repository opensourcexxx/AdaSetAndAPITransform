+                        IndexAbstraction indexAbstraction = metadata.getIndicesLookup().get(expression);
+                        if (indexAbstraction == null) {
