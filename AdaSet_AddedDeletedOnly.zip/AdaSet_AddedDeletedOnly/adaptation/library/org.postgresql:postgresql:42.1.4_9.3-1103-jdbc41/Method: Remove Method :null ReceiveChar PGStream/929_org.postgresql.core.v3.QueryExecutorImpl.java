+      int c = pgStream.receiveChar();
+      switch (c) {
