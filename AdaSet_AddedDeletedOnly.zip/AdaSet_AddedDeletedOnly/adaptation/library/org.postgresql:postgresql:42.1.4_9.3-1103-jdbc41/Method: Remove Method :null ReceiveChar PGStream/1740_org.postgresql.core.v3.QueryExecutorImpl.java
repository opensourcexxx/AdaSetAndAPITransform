+          DescribeRequest describeData = pendingDescribeStatementQueue.getFirst();
+          SimpleQuery query = describeData.query;
+          SimpleParameterList params = describeData.parameterList;
+          boolean describeOnly = describeData.describeOnly;
+          // This might differ from query.getStatementName if the query was re-prepared
+          String origStatementName = describeData.statementName;
