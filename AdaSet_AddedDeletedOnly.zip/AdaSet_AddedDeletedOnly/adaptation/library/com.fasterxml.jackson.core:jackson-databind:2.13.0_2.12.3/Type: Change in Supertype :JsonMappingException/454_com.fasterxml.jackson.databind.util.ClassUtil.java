+        throw JsonMappingException.from(ctxt, e0.getMessage())
+            .withCause(e0);
