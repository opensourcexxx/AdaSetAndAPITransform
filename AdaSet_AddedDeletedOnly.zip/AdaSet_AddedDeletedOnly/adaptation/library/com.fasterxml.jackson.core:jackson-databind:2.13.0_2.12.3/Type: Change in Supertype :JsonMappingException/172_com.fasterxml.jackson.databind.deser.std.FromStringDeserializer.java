+        throw ctxt.weirdStringException(text, _valueClass, msg)
+            .withCause(cause);
