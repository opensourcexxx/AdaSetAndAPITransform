+            DatabindException mapE = new JsonMappingException(gen, "Infinite recursion (StackOverflowError)", e);
