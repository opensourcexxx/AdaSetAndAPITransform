+            DatabindException mapE = JsonMappingException.from(gen, "Infinite recursion (StackOverflowError)", e);
+            mapE.prependPath(bean, props[i].getName());
