+		return this.rawList.set(index, JSONUtil.wrap(element, this.ignoreNullValue));
