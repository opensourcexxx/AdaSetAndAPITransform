+				result = ReflectUtil.invoke(obj, "timestampValue", new Object[]{});
