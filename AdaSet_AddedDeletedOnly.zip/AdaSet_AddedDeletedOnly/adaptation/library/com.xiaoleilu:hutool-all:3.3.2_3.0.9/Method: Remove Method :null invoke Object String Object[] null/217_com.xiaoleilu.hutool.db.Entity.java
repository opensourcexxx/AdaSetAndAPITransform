+				result = ReflectUtil.invoke(obj, "timeValue", new Object[]{});
