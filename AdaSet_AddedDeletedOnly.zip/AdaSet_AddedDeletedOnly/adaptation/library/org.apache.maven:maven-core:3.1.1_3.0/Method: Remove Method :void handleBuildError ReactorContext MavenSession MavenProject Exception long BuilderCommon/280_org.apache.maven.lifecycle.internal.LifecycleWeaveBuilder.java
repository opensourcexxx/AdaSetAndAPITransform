+                    builderCommon.handleBuildError( reactorContext, rootSession, projectBuild.getSession(),
+                                                    projectBuild.getProject(), e, buildStartTime );
