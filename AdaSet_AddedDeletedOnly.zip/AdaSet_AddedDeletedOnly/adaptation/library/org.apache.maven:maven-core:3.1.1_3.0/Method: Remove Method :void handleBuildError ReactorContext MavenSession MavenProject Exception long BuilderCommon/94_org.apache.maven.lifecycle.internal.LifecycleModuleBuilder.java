+            builderCommon.handleBuildError( reactorContext, rootSession, session, currentProject, e, buildStartTime );
