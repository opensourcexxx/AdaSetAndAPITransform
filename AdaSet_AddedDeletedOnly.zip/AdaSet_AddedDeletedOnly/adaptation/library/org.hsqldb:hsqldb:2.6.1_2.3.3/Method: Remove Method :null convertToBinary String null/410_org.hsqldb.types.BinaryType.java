+                b = session.getScanner().convertToBinary((String) a, false);
