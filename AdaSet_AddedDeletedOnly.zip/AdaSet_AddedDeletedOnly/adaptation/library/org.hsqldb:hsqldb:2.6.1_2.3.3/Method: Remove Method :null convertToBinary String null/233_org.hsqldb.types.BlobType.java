+            a = session.getScanner().convertToBinary((String) a, false);
