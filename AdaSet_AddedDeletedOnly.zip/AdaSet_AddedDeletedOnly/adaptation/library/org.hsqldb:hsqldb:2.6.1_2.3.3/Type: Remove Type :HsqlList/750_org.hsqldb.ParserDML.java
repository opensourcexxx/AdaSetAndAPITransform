+        List unresolved           = null;
+        int  enforcedDefaultIndex = -1;
