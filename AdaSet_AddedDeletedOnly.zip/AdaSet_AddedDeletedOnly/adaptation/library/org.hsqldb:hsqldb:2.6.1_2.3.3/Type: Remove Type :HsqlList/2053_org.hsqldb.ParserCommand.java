+            List unresolved = e.resolveColumnReferences(session,
