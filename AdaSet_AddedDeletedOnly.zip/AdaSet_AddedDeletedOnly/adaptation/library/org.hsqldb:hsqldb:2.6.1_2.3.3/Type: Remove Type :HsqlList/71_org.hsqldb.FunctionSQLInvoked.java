+        List conditionSet = condition.resolveColumnReferences(session,
