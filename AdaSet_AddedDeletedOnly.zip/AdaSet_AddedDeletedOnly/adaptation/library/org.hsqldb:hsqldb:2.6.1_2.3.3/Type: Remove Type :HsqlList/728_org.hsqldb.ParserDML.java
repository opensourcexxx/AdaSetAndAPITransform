+        List unresolved = condition.resolveColumnReferences(session,
