+            List unresolved = dataExpression.resolveColumnReferences(session,
+                RangeGroup.emptyGroup, rangeGroups, null);
