+            rangeVariables[i].replaceColumnReferences(session, range, list);
