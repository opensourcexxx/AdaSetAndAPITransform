+            exprColumns[i] = exprColumns[i].replaceColumnReferences(session,
+                    range, list);
