+			groupList.add( ClassLoadingHelper.loadClass( groupClass, defaultPackage ) );
