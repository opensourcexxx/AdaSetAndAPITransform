+			Class<?> payload = ClassLoadingHelper.loadClass( groupClass, defaultPackage );
