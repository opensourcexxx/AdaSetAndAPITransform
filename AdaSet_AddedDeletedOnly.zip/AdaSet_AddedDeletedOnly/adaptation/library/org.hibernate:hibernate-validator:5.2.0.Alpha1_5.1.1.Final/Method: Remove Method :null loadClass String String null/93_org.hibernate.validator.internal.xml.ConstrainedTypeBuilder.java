+				Class<?> group = ClassLoadingHelper.loadClass( groupName, defaultPackage );
