+        Table table = database.schemaManager.findTable(session,
+            token.tokenString, token.namePrefix, token.namePrePrefix);
