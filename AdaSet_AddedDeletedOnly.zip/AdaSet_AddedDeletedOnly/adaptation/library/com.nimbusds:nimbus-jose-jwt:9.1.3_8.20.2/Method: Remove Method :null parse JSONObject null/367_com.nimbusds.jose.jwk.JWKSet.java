+				Map<String, Object> keyJSONObject = (Map<String, Object>)keyArray.get(i);
+				keys.add(JWK.parse(keyJSONObject));
+				
+			} catch (ClassCastException e) {
+				
+				throw new ParseException("The \"keys\" JSON array must contain JSON objects only", 0);
+				
