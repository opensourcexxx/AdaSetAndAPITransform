+		claimsSet = JWTClaimsSet.parse(json);
+		return claimsSet;
