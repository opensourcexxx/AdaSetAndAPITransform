+            envImpl.getLogManager().getEntryHandleNotFound(lastFullLsn);
