+            envImpl.getLogManager().getEntryHandleNotFound(rootLsn);
