+        if (s.isInferenceVariable() && isProperType(t)) {
