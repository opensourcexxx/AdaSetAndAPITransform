+        if (S.isInferenceVariable()) {
