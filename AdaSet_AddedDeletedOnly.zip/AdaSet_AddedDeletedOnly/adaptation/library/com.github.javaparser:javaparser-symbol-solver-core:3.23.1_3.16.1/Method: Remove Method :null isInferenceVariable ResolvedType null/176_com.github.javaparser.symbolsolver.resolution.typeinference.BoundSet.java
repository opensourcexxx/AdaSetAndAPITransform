+        return a.isInferenceVariable() && b.isInferenceVariable() && a.equals(b);
