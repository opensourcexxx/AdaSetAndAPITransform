+        if (isProperType(s) && t.isInferenceVariable()) {
