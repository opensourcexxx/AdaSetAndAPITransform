+        if (!s.isInferenceVariable() && !t.isInferenceVariable()) {
