+        if (expression.isStandaloneExpression()) {
