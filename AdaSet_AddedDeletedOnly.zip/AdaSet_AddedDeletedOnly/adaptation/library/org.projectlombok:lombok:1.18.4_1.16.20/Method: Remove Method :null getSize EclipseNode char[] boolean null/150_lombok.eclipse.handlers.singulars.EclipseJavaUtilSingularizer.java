+		switchStat.expression = getSize(builderType, keyName, true, builderVariable);
